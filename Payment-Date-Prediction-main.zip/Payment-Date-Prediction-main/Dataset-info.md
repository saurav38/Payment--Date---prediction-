# List of all the fields part of dataset are as follows: 
<li> business_code - company code of the account </li>
<li> cust_number - customer number given to all the customers of the Account </li>
<li> name_customer - name of the customer </li>
<li> clear_date - The date on which the customer clears an invoice, or in simple terms, they make the full payment </li>
<li> buisness_year - Period that a company uses for accounting purposes and preparing financial statements. </li>
<li> doc_id - It is also an unique identifier of an invoice. (Primary Key) </li>
<li> document_create_date - The date on which the invoice document was created. </li>
<li> document_create_date_norm - Normalised date of the invoice document </li>
<li>due_in_date - The date on which the customer is expected to clear an invoice.</li>
<li>invoice_currency - The currency of the invoice amount in the document for the invoice</li>
<li>document type -It represents the type of document. eg D1 represents Invoice </li>
<li>posting_id-key indicator to identify whether an AR item is invoice, deduction, credit memo based on its value.</li>
<li>baseline_create_date-The date on which the Invoice was created</li>
<li>cust_payment_terms-Business terms and agreements between customers and accounts on discounts and days of payment</li>
<li>invoice_id-Unique number assigned when a seller creates an Invoice.</li>
<li>is_open_invoice-indicator of whether an invoice is open or closed. isopen = 1, means the invoice is open.</li>
